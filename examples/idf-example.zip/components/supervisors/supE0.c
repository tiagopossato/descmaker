#include <stdbool.h>
#include <stdlib.h>

#include "events.h"
#include "supE0.h"

// Supervisor specific instances
// alphabet create
Alphabet supE0_Se_evt0;
Alphabet supE0_a1_evt1;
Alphabet supE0_b1_evt2;

// Alphabet init
Alphabet supE0_Se_evt0 = {&Se, &supE0_a1_evt1};
Alphabet supE0_a1_evt1 = {&a1, &supE0_b1_evt2};
Alphabet supE0_b1_evt2 = {&b1, NULL};

// states create
State supE0_S0_S0_S0;
State supE0_S0_S0_S1;
State supE0_S0_S1_S0;
State supE0_S0_S1_S1;

// transitions create and init
Transition supE0_S0_S0_S0_t0;
Transition supE0_S0_S0_S0_t0 = {&Se, &supE0_S0_S0_S1, NULL};

Transition supE0_S0_S0_S1_t0;
Transition supE0_S0_S0_S1_t1;
Transition supE0_S0_S0_S1_t0 = {&Se, &supE0_S0_S0_S1, &supE0_S0_S0_S1_t1};
Transition supE0_S0_S0_S1_t1 = {&a1, &supE0_S0_S1_S0, NULL};

Transition supE0_S0_S1_S0_t0;
Transition supE0_S0_S1_S0_t1;
Transition supE0_S0_S1_S0_t0 = {&b1, &supE0_S0_S0_S0, &supE0_S0_S1_S0_t1};
Transition supE0_S0_S1_S0_t1 = {&Se, &supE0_S0_S1_S1, NULL};

Transition supE0_S0_S1_S1_t0;
Transition supE0_S0_S1_S1_t1;
Transition supE0_S0_S1_S1_t0 = {&b1, &supE0_S0_S0_S1, &supE0_S0_S1_S1_t1};
Transition supE0_S0_S1_S1_t1 = {&Se, &supE0_S0_S1_S1, NULL};


// states init
State supE0_S0_S0_S0 = {true, SUP_DEBUG_STR("S0_S0_S0"), &supE0_S0_S0_S0_t0};
State supE0_S0_S0_S1 = {false, SUP_DEBUG_STR("S0_S0_S1"), &supE0_S0_S0_S1_t0};
State supE0_S0_S1_S0 = {false, SUP_DEBUG_STR("S0_S1_S0"), &supE0_S0_S1_S0_t0};
State supE0_S0_S1_S1 = {false, SUP_DEBUG_STR("S0_S1_S1"), &supE0_S0_S1_S1_t0};

// Supervisor create
Supervisor supE0 = {&supE0_S0_S0_S0, &supE0_S0_S0_S0, NULL,  &supE0_Se_evt0, "supE0"};
