#include <stdio.h>
#include "events.h"
#include "handle_event.h"

#include "supE0.h"
#include "supE1.h"
#include "supE2.h"
#include "supE3.h"
#include "supE4.h"
#include "supE5.h"
#include "supE6.h"
#include "supE7.h"
#include "supE8.h"



/**
 * @brief The alphabet
 */
typedef struct _SupervisorList SupervisorList;
struct _SupervisorList {
  Supervisor *supervisor;
  SupervisorList *next;
};

// make list with all supervisors
// first create all supervisors
extern SupervisorList supE0_list;
extern SupervisorList supE1_list;
extern SupervisorList supE2_list;
extern SupervisorList supE3_list;
extern SupervisorList supE4_list;
extern SupervisorList supE5_list;
extern SupervisorList supE6_list;
extern SupervisorList supE7_list;
extern SupervisorList supE8_list;

// then recreate and linking them
SupervisorList supE0_list = {&supE0, &supE1_list};
SupervisorList supE1_list = {&supE1, &supE2_list};
SupervisorList supE2_list = {&supE2, &supE3_list};
SupervisorList supE3_list = {&supE3, &supE4_list};
SupervisorList supE4_list = {&supE4, &supE5_list};
SupervisorList supE5_list = {&supE5, &supE6_list};
SupervisorList supE6_list = {&supE6, &supE7_list};
SupervisorList supE7_list = {&supE7, &supE8_list};
SupervisorList supE8_list = {&supE8, NULL};

bool handle_event(Event *event) {
  // check if event is enabled in all supervisors
  SupervisorList *sup = &supE0_list;
  bool event_enabled = false;
  while (sup != NULL) {
    if (is_event_in_supervisor_alphabet(sup->supervisor, event)) {
      if (is_supervisor_event_enabled(sup->supervisor, event)) {
        event_enabled = true;
      } else {
        SUP_DEBUG_PRINT("Event %s %s is not enabled in supervisor %s!\n",
                        event->kind == CONTROLLABLE
                            ? SUP_DEBUG_STR("CONTROLLABLE")
                            : SUP_DEBUG_STR("UNCONTROLLABLE"),
                        event->name, sup->supervisor->name);
        return false;
      }
    }
    sup = sup->next;
  }

  if (event_enabled == false) {
    SUP_DEBUG_PRINT("Event %s %s is not in any supervisor alphabet!\n",
                    event->kind == CONTROLLABLE
                        ? SUP_DEBUG_STR("CONTROLLABLE")
                        : SUP_DEBUG_STR("UNCONTROLLABLE"),
                    event->name);
    return false;
  }
  // run all supervisors
  sup = &supE0_list;
  while (sup != NULL) {
    if (is_event_in_supervisor_alphabet(sup->supervisor, event)) {
      run_supervisor(sup->supervisor, event);
    }
    sup = sup->next;
  }

  run_event_callback(event);

  return true;
}