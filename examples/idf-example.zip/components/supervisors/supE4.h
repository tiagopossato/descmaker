#ifndef __SUPE4_H__
#define __SUPE4_H__

#include <stdbool.h>
#include <stdlib.h>

#include "supervisor.h"
// Supervisor create
extern Supervisor supE4;

#endif // __SUPE4_H__