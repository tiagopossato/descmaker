#ifndef __SUPE2_H__
#define __SUPE2_H__

#include <stdbool.h>
#include <stdlib.h>

#include "supervisor.h"
// Supervisor create
extern Supervisor supE2;

#endif // __SUPE2_H__