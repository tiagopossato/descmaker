#include <stdbool.h>
#include <stdlib.h>

#include "events.h"
#include "supE6.h"

// Supervisor specific instances
// alphabet create
Alphabet supE6_a0_evt0;
Alphabet supE6_a2_evt1;
Alphabet supE6_b3_evt2;
Alphabet supE6_b0_evt3;
Alphabet supE6_b2_evt4;
Alphabet supE6_a3_evt5;

// Alphabet init
Alphabet supE6_a0_evt0 = {&a0, &supE6_a2_evt1};
Alphabet supE6_a2_evt1 = {&a2, &supE6_b3_evt2};
Alphabet supE6_b3_evt2 = {&b3, &supE6_b0_evt3};
Alphabet supE6_b0_evt3 = {&b0, &supE6_b2_evt4};
Alphabet supE6_b2_evt4 = {&b2, &supE6_a3_evt5};
Alphabet supE6_a3_evt5 = {&a3, NULL};

// states create
State supE6_S0_S0_S0_S0;
State supE6_S0_S0_S0_S1;
State supE6_S0_S0_S1_S0;
State supE6_S0_S0_S1_S1;
State supE6_S0_S1_S0_S0;
State supE6_S0_S1_S0_S1;
State supE6_S0_S1_S1_S0;
State supE6_S0_S1_S1_S1;
State supE6_S1_S0_S0_S0;
State supE6_S1_S0_S0_S1;
State supE6_S1_S0_S1_S0;
State supE6_S1_S0_S1_S1;
State supE6_S1_S1_S0_S0;
State supE6_S1_S1_S0_S1;
State supE6_S1_S1_S1_S0;
State supE6_S1_S1_S1_S1;
State supE6_S2_S0_S0_S0;
State supE6_S2_S0_S0_S1;
State supE6_S2_S0_S1_S0;
State supE6_S2_S0_S1_S1;
State supE6_S3_S0_S0_S0;
State supE6_S3_S0_S0_S1;
State supE6_S3_S0_S1_S0;
State supE6_S3_S0_S1_S1;

// transitions create and init
Transition supE6_S0_S0_S0_S0_t0;
Transition supE6_S0_S0_S0_S0_t1;
Transition supE6_S0_S0_S0_S0_t0 = {&a0, &supE6_S0_S0_S1_S0, &supE6_S0_S0_S0_S0_t1};
Transition supE6_S0_S0_S0_S0_t1 = {&a2, &supE6_S0_S1_S0_S0, NULL};

Transition supE6_S0_S0_S0_S1_t0;
Transition supE6_S0_S0_S0_S1_t1;
Transition supE6_S0_S0_S0_S1_t2;
Transition supE6_S0_S0_S0_S1_t0 = {&b3, &supE6_S0_S0_S0_S0, &supE6_S0_S0_S0_S1_t1};
Transition supE6_S0_S0_S0_S1_t1 = {&a0, &supE6_S0_S0_S1_S1, &supE6_S0_S0_S0_S1_t2};
Transition supE6_S0_S0_S0_S1_t2 = {&a2, &supE6_S0_S1_S0_S1, NULL};

Transition supE6_S0_S0_S1_S0_t0;
Transition supE6_S0_S0_S1_S0_t1;
Transition supE6_S0_S0_S1_S0_t0 = {&b0, &supE6_S0_S0_S0_S0, &supE6_S0_S0_S1_S0_t1};
Transition supE6_S0_S0_S1_S0_t1 = {&a2, &supE6_S0_S1_S1_S0, NULL};

Transition supE6_S0_S0_S1_S1_t0;
Transition supE6_S0_S0_S1_S1_t1;
Transition supE6_S0_S0_S1_S1_t2;
Transition supE6_S0_S0_S1_S1_t0 = {&b0, &supE6_S0_S0_S0_S1, &supE6_S0_S0_S1_S1_t1};
Transition supE6_S0_S0_S1_S1_t1 = {&b3, &supE6_S0_S0_S1_S0, &supE6_S0_S0_S1_S1_t2};
Transition supE6_S0_S0_S1_S1_t2 = {&a2, &supE6_S0_S1_S1_S1, NULL};

Transition supE6_S0_S1_S0_S0_t0;
Transition supE6_S0_S1_S0_S0_t1;
Transition supE6_S0_S1_S0_S0_t0 = {&a0, &supE6_S0_S1_S1_S0, &supE6_S0_S1_S0_S0_t1};
Transition supE6_S0_S1_S0_S0_t1 = {&b2, &supE6_S2_S0_S0_S0, NULL};

Transition supE6_S0_S1_S0_S1_t0;
Transition supE6_S0_S1_S0_S1_t1;
Transition supE6_S0_S1_S0_S1_t2;
Transition supE6_S0_S1_S0_S1_t0 = {&b3, &supE6_S0_S1_S0_S0, &supE6_S0_S1_S0_S1_t1};
Transition supE6_S0_S1_S0_S1_t1 = {&a0, &supE6_S0_S1_S1_S1, &supE6_S0_S1_S0_S1_t2};
Transition supE6_S0_S1_S0_S1_t2 = {&b2, &supE6_S2_S0_S0_S1, NULL};

Transition supE6_S0_S1_S1_S0_t0;
Transition supE6_S0_S1_S1_S0_t1;
Transition supE6_S0_S1_S1_S0_t0 = {&b0, &supE6_S0_S1_S0_S0, &supE6_S0_S1_S1_S0_t1};
Transition supE6_S0_S1_S1_S0_t1 = {&b2, &supE6_S2_S0_S1_S0, NULL};

Transition supE6_S0_S1_S1_S1_t0;
Transition supE6_S0_S1_S1_S1_t1;
Transition supE6_S0_S1_S1_S1_t2;
Transition supE6_S0_S1_S1_S1_t0 = {&b0, &supE6_S0_S1_S0_S1, &supE6_S0_S1_S1_S1_t1};
Transition supE6_S0_S1_S1_S1_t1 = {&b3, &supE6_S0_S1_S1_S0, &supE6_S0_S1_S1_S1_t2};
Transition supE6_S0_S1_S1_S1_t2 = {&b2, &supE6_S2_S0_S1_S1, NULL};

Transition supE6_S1_S0_S0_S0_t0;
Transition supE6_S1_S0_S0_S0_t1;
Transition supE6_S1_S0_S0_S0_t0 = {&a3, &supE6_S0_S0_S0_S1, &supE6_S1_S0_S0_S0_t1};
Transition supE6_S1_S0_S0_S0_t1 = {&a2, &supE6_S1_S1_S0_S0, NULL};

Transition supE6_S1_S0_S0_S1_t0;
Transition supE6_S1_S0_S0_S1_t1;
Transition supE6_S1_S0_S0_S1_t0 = {&b3, &supE6_S1_S0_S0_S0, &supE6_S1_S0_S0_S1_t1};
Transition supE6_S1_S0_S0_S1_t1 = {&a2, &supE6_S1_S1_S0_S1, NULL};

Transition supE6_S1_S0_S1_S0_t0;
Transition supE6_S1_S0_S1_S0_t1;
Transition supE6_S1_S0_S1_S0_t2;
Transition supE6_S1_S0_S1_S0_t0 = {&a3, &supE6_S0_S0_S1_S1, &supE6_S1_S0_S1_S0_t1};
Transition supE6_S1_S0_S1_S0_t1 = {&b0, &supE6_S1_S0_S0_S0, &supE6_S1_S0_S1_S0_t2};
Transition supE6_S1_S0_S1_S0_t2 = {&a2, &supE6_S1_S1_S1_S0, NULL};

Transition supE6_S1_S0_S1_S1_t0;
Transition supE6_S1_S0_S1_S1_t1;
Transition supE6_S1_S0_S1_S1_t2;
Transition supE6_S1_S0_S1_S1_t0 = {&b0, &supE6_S1_S0_S0_S1, &supE6_S1_S0_S1_S1_t1};
Transition supE6_S1_S0_S1_S1_t1 = {&b3, &supE6_S1_S0_S1_S0, &supE6_S1_S0_S1_S1_t2};
Transition supE6_S1_S0_S1_S1_t2 = {&a2, &supE6_S1_S1_S1_S1, NULL};

Transition supE6_S1_S1_S0_S0_t0;
Transition supE6_S1_S1_S0_S0_t1;
Transition supE6_S1_S1_S0_S0_t0 = {&a3, &supE6_S0_S1_S0_S1, &supE6_S1_S1_S0_S0_t1};
Transition supE6_S1_S1_S0_S0_t1 = {&b2, &supE6_S3_S0_S0_S0, NULL};

Transition supE6_S1_S1_S0_S1_t0;
Transition supE6_S1_S1_S0_S1_t1;
Transition supE6_S1_S1_S0_S1_t0 = {&b3, &supE6_S1_S1_S0_S0, &supE6_S1_S1_S0_S1_t1};
Transition supE6_S1_S1_S0_S1_t1 = {&b2, &supE6_S3_S0_S0_S1, NULL};

Transition supE6_S1_S1_S1_S0_t0;
Transition supE6_S1_S1_S1_S0_t1;
Transition supE6_S1_S1_S1_S0_t2;
Transition supE6_S1_S1_S1_S0_t0 = {&a3, &supE6_S0_S1_S1_S1, &supE6_S1_S1_S1_S0_t1};
Transition supE6_S1_S1_S1_S0_t1 = {&b0, &supE6_S1_S1_S0_S0, &supE6_S1_S1_S1_S0_t2};
Transition supE6_S1_S1_S1_S0_t2 = {&b2, &supE6_S3_S0_S1_S0, NULL};

Transition supE6_S1_S1_S1_S1_t0;
Transition supE6_S1_S1_S1_S1_t1;
Transition supE6_S1_S1_S1_S1_t2;
Transition supE6_S1_S1_S1_S1_t0 = {&b0, &supE6_S1_S1_S0_S1, &supE6_S1_S1_S1_S1_t1};
Transition supE6_S1_S1_S1_S1_t1 = {&b3, &supE6_S1_S1_S1_S0, &supE6_S1_S1_S1_S1_t2};
Transition supE6_S1_S1_S1_S1_t2 = {&b2, &supE6_S3_S0_S1_S1, NULL};

Transition supE6_S2_S0_S0_S0_t0;
Transition supE6_S2_S0_S0_S0_t0 = {&a0, &supE6_S1_S0_S1_S0, NULL};

Transition supE6_S2_S0_S0_S1_t0;
Transition supE6_S2_S0_S0_S1_t1;
Transition supE6_S2_S0_S0_S1_t0 = {&a0, &supE6_S1_S0_S1_S1, &supE6_S2_S0_S0_S1_t1};
Transition supE6_S2_S0_S0_S1_t1 = {&b3, &supE6_S2_S0_S0_S0, NULL};

Transition supE6_S2_S0_S1_S0_t0;
Transition supE6_S2_S0_S1_S0_t0 = {&b0, &supE6_S2_S0_S0_S0, NULL};

Transition supE6_S2_S0_S1_S1_t0;
Transition supE6_S2_S0_S1_S1_t1;
Transition supE6_S2_S0_S1_S1_t0 = {&b0, &supE6_S2_S0_S0_S1, &supE6_S2_S0_S1_S1_t1};
Transition supE6_S2_S0_S1_S1_t1 = {&b3, &supE6_S2_S0_S1_S0, NULL};

Transition supE6_S3_S0_S0_S0_t0;
Transition supE6_S3_S0_S0_S0_t0 = {&a3, &supE6_S2_S0_S0_S1, NULL};

Transition supE6_S3_S0_S0_S1_t0;
Transition supE6_S3_S0_S0_S1_t0 = {&b3, &supE6_S3_S0_S0_S0, NULL};

Transition supE6_S3_S0_S1_S0_t0;
Transition supE6_S3_S0_S1_S0_t1;
Transition supE6_S3_S0_S1_S0_t0 = {&a3, &supE6_S2_S0_S1_S1, &supE6_S3_S0_S1_S0_t1};
Transition supE6_S3_S0_S1_S0_t1 = {&b0, &supE6_S3_S0_S0_S0, NULL};

Transition supE6_S3_S0_S1_S1_t0;
Transition supE6_S3_S0_S1_S1_t1;
Transition supE6_S3_S0_S1_S1_t0 = {&b0, &supE6_S3_S0_S0_S1, &supE6_S3_S0_S1_S1_t1};
Transition supE6_S3_S0_S1_S1_t1 = {&b3, &supE6_S3_S0_S1_S0, NULL};


// states init
State supE6_S0_S0_S0_S0 = {true, SUP_DEBUG_STR("S0_S0_S0_S0"), &supE6_S0_S0_S0_S0_t0};
State supE6_S0_S0_S0_S1 = {false, SUP_DEBUG_STR("S0_S0_S0_S1"), &supE6_S0_S0_S0_S1_t0};
State supE6_S0_S0_S1_S0 = {false, SUP_DEBUG_STR("S0_S0_S1_S0"), &supE6_S0_S0_S1_S0_t0};
State supE6_S0_S0_S1_S1 = {false, SUP_DEBUG_STR("S0_S0_S1_S1"), &supE6_S0_S0_S1_S1_t0};
State supE6_S0_S1_S0_S0 = {false, SUP_DEBUG_STR("S0_S1_S0_S0"), &supE6_S0_S1_S0_S0_t0};
State supE6_S0_S1_S0_S1 = {false, SUP_DEBUG_STR("S0_S1_S0_S1"), &supE6_S0_S1_S0_S1_t0};
State supE6_S0_S1_S1_S0 = {false, SUP_DEBUG_STR("S0_S1_S1_S0"), &supE6_S0_S1_S1_S0_t0};
State supE6_S0_S1_S1_S1 = {false, SUP_DEBUG_STR("S0_S1_S1_S1"), &supE6_S0_S1_S1_S1_t0};
State supE6_S1_S0_S0_S0 = {false, SUP_DEBUG_STR("S1_S0_S0_S0"), &supE6_S1_S0_S0_S0_t0};
State supE6_S1_S0_S0_S1 = {false, SUP_DEBUG_STR("S1_S0_S0_S1"), &supE6_S1_S0_S0_S1_t0};
State supE6_S1_S0_S1_S0 = {false, SUP_DEBUG_STR("S1_S0_S1_S0"), &supE6_S1_S0_S1_S0_t0};
State supE6_S1_S0_S1_S1 = {false, SUP_DEBUG_STR("S1_S0_S1_S1"), &supE6_S1_S0_S1_S1_t0};
State supE6_S1_S1_S0_S0 = {false, SUP_DEBUG_STR("S1_S1_S0_S0"), &supE6_S1_S1_S0_S0_t0};
State supE6_S1_S1_S0_S1 = {false, SUP_DEBUG_STR("S1_S1_S0_S1"), &supE6_S1_S1_S0_S1_t0};
State supE6_S1_S1_S1_S0 = {false, SUP_DEBUG_STR("S1_S1_S1_S0"), &supE6_S1_S1_S1_S0_t0};
State supE6_S1_S1_S1_S1 = {false, SUP_DEBUG_STR("S1_S1_S1_S1"), &supE6_S1_S1_S1_S1_t0};
State supE6_S2_S0_S0_S0 = {false, SUP_DEBUG_STR("S2_S0_S0_S0"), &supE6_S2_S0_S0_S0_t0};
State supE6_S2_S0_S0_S1 = {false, SUP_DEBUG_STR("S2_S0_S0_S1"), &supE6_S2_S0_S0_S1_t0};
State supE6_S2_S0_S1_S0 = {false, SUP_DEBUG_STR("S2_S0_S1_S0"), &supE6_S2_S0_S1_S0_t0};
State supE6_S2_S0_S1_S1 = {false, SUP_DEBUG_STR("S2_S0_S1_S1"), &supE6_S2_S0_S1_S1_t0};
State supE6_S3_S0_S0_S0 = {false, SUP_DEBUG_STR("S3_S0_S0_S0"), &supE6_S3_S0_S0_S0_t0};
State supE6_S3_S0_S0_S1 = {false, SUP_DEBUG_STR("S3_S0_S0_S1"), &supE6_S3_S0_S0_S1_t0};
State supE6_S3_S0_S1_S0 = {false, SUP_DEBUG_STR("S3_S0_S1_S0"), &supE6_S3_S0_S1_S0_t0};
State supE6_S3_S0_S1_S1 = {false, SUP_DEBUG_STR("S3_S0_S1_S1"), &supE6_S3_S0_S1_S1_t0};

// Supervisor create
Supervisor supE6 = {&supE6_S0_S0_S0_S0, &supE6_S0_S0_S0_S0, NULL,  &supE6_a0_evt0, "supE6"};
