#ifndef __SUPE3_H__
#define __SUPE3_H__

#include <stdbool.h>
#include <stdlib.h>

#include "supervisor.h"
// Supervisor create
extern Supervisor supE3;

#endif // __SUPE3_H__