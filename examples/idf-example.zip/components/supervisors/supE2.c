#include <stdbool.h>
#include <stdlib.h>

#include "events.h"
#include "supE2.h"

// Supervisor specific instances
// alphabet create
Alphabet supE2_a0_evt0;
Alphabet supE2_a2_evt1;
Alphabet supE2_b0_evt2;
Alphabet supE2_b2_evt3;

// Alphabet init
Alphabet supE2_a0_evt0 = {&a0, &supE2_a2_evt1};
Alphabet supE2_a2_evt1 = {&a2, &supE2_b0_evt2};
Alphabet supE2_b0_evt2 = {&b0, &supE2_b2_evt3};
Alphabet supE2_b2_evt3 = {&b2, NULL};

// states create
State supE2_S0_S0_S0;
State supE2_S1_S0_S1;
State supE2_S1_S1_S0;

// transitions create and init
Transition supE2_S0_S0_S0_t0;
Transition supE2_S0_S0_S0_t1;
Transition supE2_S0_S0_S0_t0 = {&a0, &supE2_S1_S0_S1, &supE2_S0_S0_S0_t1};
Transition supE2_S0_S0_S0_t1 = {&a2, &supE2_S1_S1_S0, NULL};

Transition supE2_S1_S0_S1_t0;
Transition supE2_S1_S0_S1_t0 = {&b0, &supE2_S0_S0_S0, NULL};

Transition supE2_S1_S1_S0_t0;
Transition supE2_S1_S1_S0_t0 = {&b2, &supE2_S0_S0_S0, NULL};


// states init
State supE2_S0_S0_S0 = {true, SUP_DEBUG_STR("S0_S0_S0"), &supE2_S0_S0_S0_t0};
State supE2_S1_S0_S1 = {false, SUP_DEBUG_STR("S1_S0_S1"), &supE2_S1_S0_S1_t0};
State supE2_S1_S1_S0 = {false, SUP_DEBUG_STR("S1_S1_S0"), &supE2_S1_S1_S0_t0};

// Supervisor create
Supervisor supE2 = {&supE2_S0_S0_S0, &supE2_S0_S0_S0, NULL,  &supE2_a0_evt0, "supE2"};
