#ifndef __SUPE7_H__
#define __SUPE7_H__

#include <stdbool.h>
#include <stdlib.h>

#include "supervisor.h"
// Supervisor create
extern Supervisor supE7;

#endif // __SUPE7_H__