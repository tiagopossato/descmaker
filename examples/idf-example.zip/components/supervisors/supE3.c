#include <stdbool.h>
#include <stdlib.h>

#include "events.h"
#include "supE3.h"

// Supervisor specific instances
// alphabet create
Alphabet supE3_a3_evt0;
Alphabet supE3_a0_evt1;
Alphabet supE3_b3_evt2;
Alphabet supE3_b0_evt3;

// Alphabet init
Alphabet supE3_a3_evt0 = {&a3, &supE3_a0_evt1};
Alphabet supE3_a0_evt1 = {&a0, &supE3_b3_evt2};
Alphabet supE3_b3_evt2 = {&b3, &supE3_b0_evt3};
Alphabet supE3_b0_evt3 = {&b0, NULL};

// states create
State supE3_S0_S0_S0;
State supE3_S0_S1_S1;
State supE3_S1_S0_S1;

// transitions create and init
Transition supE3_S0_S0_S0_t0;
Transition supE3_S0_S0_S0_t1;
Transition supE3_S0_S0_S0_t0 = {&a3, &supE3_S0_S1_S1, &supE3_S0_S0_S0_t1};
Transition supE3_S0_S0_S0_t1 = {&a0, &supE3_S1_S0_S1, NULL};

Transition supE3_S0_S1_S1_t0;
Transition supE3_S0_S1_S1_t0 = {&b3, &supE3_S0_S0_S0, NULL};

Transition supE3_S1_S0_S1_t0;
Transition supE3_S1_S0_S1_t0 = {&b0, &supE3_S0_S0_S0, NULL};


// states init
State supE3_S0_S0_S0 = {true, SUP_DEBUG_STR("S0_S0_S0"), &supE3_S0_S0_S0_t0};
State supE3_S0_S1_S1 = {false, SUP_DEBUG_STR("S0_S1_S1"), &supE3_S0_S1_S1_t0};
State supE3_S1_S0_S1 = {false, SUP_DEBUG_STR("S1_S0_S1"), &supE3_S1_S0_S1_t0};

// Supervisor create
Supervisor supE3 = {&supE3_S0_S0_S0, &supE3_S0_S0_S0, NULL,  &supE3_a3_evt0, "supE3"};
