#ifndef __SUPE8_H__
#define __SUPE8_H__

#include <stdbool.h>
#include <stdlib.h>

#include "supervisor.h"
// Supervisor create
extern Supervisor supE8;

#endif // __SUPE8_H__