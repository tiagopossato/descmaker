#include <stdbool.h>
#include <stdlib.h>

#include "events.h"
#include "supE5.h"

// Supervisor specific instances
// alphabet create
Alphabet supE5_a0_evt0;
Alphabet supE5_a1_evt1;
Alphabet supE5_a2_evt2;
Alphabet supE5_b2_evt3;
Alphabet supE5_b0_evt4;
Alphabet supE5_b1_evt5;

// Alphabet init
Alphabet supE5_a0_evt0 = {&a0, &supE5_a1_evt1};
Alphabet supE5_a1_evt1 = {&a1, &supE5_a2_evt2};
Alphabet supE5_a2_evt2 = {&a2, &supE5_b2_evt3};
Alphabet supE5_b2_evt3 = {&b2, &supE5_b0_evt4};
Alphabet supE5_b0_evt4 = {&b0, &supE5_b1_evt5};
Alphabet supE5_b1_evt5 = {&b1, NULL};

// states create
State supE5_S0_S0_S0_S0;
State supE5_S0_S0_S0_S1;
State supE5_S0_S0_S0_S2;
State supE5_S0_S0_S0_S3;
State supE5_S0_S0_S1_S0;
State supE5_S0_S0_S1_S1;
State supE5_S0_S0_S1_S2;
State supE5_S0_S0_S1_S3;
State supE5_S0_S1_S0_S0;
State supE5_S0_S1_S0_S1;
State supE5_S0_S1_S0_S2;
State supE5_S0_S1_S0_S3;
State supE5_S0_S1_S1_S0;
State supE5_S0_S1_S1_S1;
State supE5_S0_S1_S1_S2;
State supE5_S0_S1_S1_S3;
State supE5_S1_S0_S0_S0;
State supE5_S1_S0_S0_S1;
State supE5_S1_S0_S1_S0;
State supE5_S1_S0_S1_S1;
State supE5_S1_S1_S0_S0;
State supE5_S1_S1_S0_S1;
State supE5_S1_S1_S1_S0;
State supE5_S1_S1_S1_S1;

// transitions create and init
Transition supE5_S0_S0_S0_S0_t0;
Transition supE5_S0_S0_S0_S0_t1;
Transition supE5_S0_S0_S0_S0_t0 = {&a0, &supE5_S0_S1_S0_S0, &supE5_S0_S0_S0_S0_t1};
Transition supE5_S0_S0_S0_S0_t1 = {&a1, &supE5_S1_S0_S0_S0, NULL};

Transition supE5_S0_S0_S0_S1_t0;
Transition supE5_S0_S0_S0_S1_t1;
Transition supE5_S0_S0_S0_S1_t0 = {&a2, &supE5_S0_S0_S1_S0, &supE5_S0_S0_S0_S1_t1};
Transition supE5_S0_S0_S0_S1_t1 = {&a1, &supE5_S1_S0_S0_S1, NULL};

Transition supE5_S0_S0_S0_S2_t0;
Transition supE5_S0_S0_S0_S2_t0 = {&a0, &supE5_S0_S1_S0_S1, NULL};

Transition supE5_S0_S0_S0_S3_t0;
Transition supE5_S0_S0_S0_S3_t0 = {&a2, &supE5_S0_S0_S1_S2, NULL};

Transition supE5_S0_S0_S1_S0_t0;
Transition supE5_S0_S0_S1_S0_t1;
Transition supE5_S0_S0_S1_S0_t2;
Transition supE5_S0_S0_S1_S0_t0 = {&b2, &supE5_S0_S0_S0_S0, &supE5_S0_S0_S1_S0_t1};
Transition supE5_S0_S0_S1_S0_t1 = {&a0, &supE5_S0_S1_S1_S0, &supE5_S0_S0_S1_S0_t2};
Transition supE5_S0_S0_S1_S0_t2 = {&a1, &supE5_S1_S0_S1_S0, NULL};

Transition supE5_S0_S0_S1_S1_t0;
Transition supE5_S0_S0_S1_S1_t1;
Transition supE5_S0_S0_S1_S1_t0 = {&b2, &supE5_S0_S0_S0_S1, &supE5_S0_S0_S1_S1_t1};
Transition supE5_S0_S0_S1_S1_t1 = {&a1, &supE5_S1_S0_S1_S1, NULL};

Transition supE5_S0_S0_S1_S2_t0;
Transition supE5_S0_S0_S1_S2_t1;
Transition supE5_S0_S0_S1_S2_t0 = {&b2, &supE5_S0_S0_S0_S2, &supE5_S0_S0_S1_S2_t1};
Transition supE5_S0_S0_S1_S2_t1 = {&a0, &supE5_S0_S1_S1_S1, NULL};

Transition supE5_S0_S0_S1_S3_t0;
Transition supE5_S0_S0_S1_S3_t0 = {&b2, &supE5_S0_S0_S0_S3, NULL};

Transition supE5_S0_S1_S0_S0_t0;
Transition supE5_S0_S1_S0_S0_t1;
Transition supE5_S0_S1_S0_S0_t0 = {&b0, &supE5_S0_S0_S0_S0, &supE5_S0_S1_S0_S0_t1};
Transition supE5_S0_S1_S0_S0_t1 = {&a1, &supE5_S1_S1_S0_S0, NULL};

Transition supE5_S0_S1_S0_S1_t0;
Transition supE5_S0_S1_S0_S1_t1;
Transition supE5_S0_S1_S0_S1_t2;
Transition supE5_S0_S1_S0_S1_t0 = {&b0, &supE5_S0_S0_S0_S1, &supE5_S0_S1_S0_S1_t1};
Transition supE5_S0_S1_S0_S1_t1 = {&a2, &supE5_S0_S1_S1_S0, &supE5_S0_S1_S0_S1_t2};
Transition supE5_S0_S1_S0_S1_t2 = {&a1, &supE5_S1_S1_S0_S1, NULL};

Transition supE5_S0_S1_S0_S2_t0;
Transition supE5_S0_S1_S0_S2_t0 = {&b0, &supE5_S0_S0_S0_S2, NULL};

Transition supE5_S0_S1_S0_S3_t0;
Transition supE5_S0_S1_S0_S3_t1;
Transition supE5_S0_S1_S0_S3_t0 = {&b0, &supE5_S0_S0_S0_S3, &supE5_S0_S1_S0_S3_t1};
Transition supE5_S0_S1_S0_S3_t1 = {&a2, &supE5_S0_S1_S1_S2, NULL};

Transition supE5_S0_S1_S1_S0_t0;
Transition supE5_S0_S1_S1_S0_t1;
Transition supE5_S0_S1_S1_S0_t2;
Transition supE5_S0_S1_S1_S0_t0 = {&b0, &supE5_S0_S0_S1_S0, &supE5_S0_S1_S1_S0_t1};
Transition supE5_S0_S1_S1_S0_t1 = {&b2, &supE5_S0_S1_S0_S0, &supE5_S0_S1_S1_S0_t2};
Transition supE5_S0_S1_S1_S0_t2 = {&a1, &supE5_S1_S1_S1_S0, NULL};

Transition supE5_S0_S1_S1_S1_t0;
Transition supE5_S0_S1_S1_S1_t1;
Transition supE5_S0_S1_S1_S1_t2;
Transition supE5_S0_S1_S1_S1_t0 = {&b0, &supE5_S0_S0_S1_S1, &supE5_S0_S1_S1_S1_t1};
Transition supE5_S0_S1_S1_S1_t1 = {&b2, &supE5_S0_S1_S0_S1, &supE5_S0_S1_S1_S1_t2};
Transition supE5_S0_S1_S1_S1_t2 = {&a1, &supE5_S1_S1_S1_S1, NULL};

Transition supE5_S0_S1_S1_S2_t0;
Transition supE5_S0_S1_S1_S2_t1;
Transition supE5_S0_S1_S1_S2_t0 = {&b0, &supE5_S0_S0_S1_S2, &supE5_S0_S1_S1_S2_t1};
Transition supE5_S0_S1_S1_S2_t1 = {&b2, &supE5_S0_S1_S0_S2, NULL};

Transition supE5_S0_S1_S1_S3_t0;
Transition supE5_S0_S1_S1_S3_t1;
Transition supE5_S0_S1_S1_S3_t0 = {&b0, &supE5_S0_S0_S1_S3, &supE5_S0_S1_S1_S3_t1};
Transition supE5_S0_S1_S1_S3_t1 = {&b2, &supE5_S0_S1_S0_S3, NULL};

Transition supE5_S1_S0_S0_S0_t0;
Transition supE5_S1_S0_S0_S0_t1;
Transition supE5_S1_S0_S0_S0_t0 = {&b1, &supE5_S0_S0_S0_S2, &supE5_S1_S0_S0_S0_t1};
Transition supE5_S1_S0_S0_S0_t1 = {&a0, &supE5_S1_S1_S0_S0, NULL};

Transition supE5_S1_S0_S0_S1_t0;
Transition supE5_S1_S0_S0_S1_t1;
Transition supE5_S1_S0_S0_S1_t0 = {&b1, &supE5_S0_S0_S0_S3, &supE5_S1_S0_S0_S1_t1};
Transition supE5_S1_S0_S0_S1_t1 = {&a2, &supE5_S1_S0_S1_S0, NULL};

Transition supE5_S1_S0_S1_S0_t0;
Transition supE5_S1_S0_S1_S0_t1;
Transition supE5_S1_S0_S1_S0_t2;
Transition supE5_S1_S0_S1_S0_t0 = {&b1, &supE5_S0_S0_S1_S2, &supE5_S1_S0_S1_S0_t1};
Transition supE5_S1_S0_S1_S0_t1 = {&b2, &supE5_S1_S0_S0_S0, &supE5_S1_S0_S1_S0_t2};
Transition supE5_S1_S0_S1_S0_t2 = {&a0, &supE5_S1_S1_S1_S0, NULL};

Transition supE5_S1_S0_S1_S1_t0;
Transition supE5_S1_S0_S1_S1_t1;
Transition supE5_S1_S0_S1_S1_t0 = {&b1, &supE5_S0_S0_S1_S3, &supE5_S1_S0_S1_S1_t1};
Transition supE5_S1_S0_S1_S1_t1 = {&b2, &supE5_S1_S0_S0_S1, NULL};

Transition supE5_S1_S1_S0_S0_t0;
Transition supE5_S1_S1_S0_S0_t1;
Transition supE5_S1_S1_S0_S0_t0 = {&b1, &supE5_S0_S1_S0_S2, &supE5_S1_S1_S0_S0_t1};
Transition supE5_S1_S1_S0_S0_t1 = {&b0, &supE5_S1_S0_S0_S0, NULL};

Transition supE5_S1_S1_S0_S1_t0;
Transition supE5_S1_S1_S0_S1_t1;
Transition supE5_S1_S1_S0_S1_t2;
Transition supE5_S1_S1_S0_S1_t0 = {&b1, &supE5_S0_S1_S0_S3, &supE5_S1_S1_S0_S1_t1};
Transition supE5_S1_S1_S0_S1_t1 = {&b0, &supE5_S1_S0_S0_S1, &supE5_S1_S1_S0_S1_t2};
Transition supE5_S1_S1_S0_S1_t2 = {&a2, &supE5_S1_S1_S1_S0, NULL};

Transition supE5_S1_S1_S1_S0_t0;
Transition supE5_S1_S1_S1_S0_t1;
Transition supE5_S1_S1_S1_S0_t2;
Transition supE5_S1_S1_S1_S0_t0 = {&b1, &supE5_S0_S1_S1_S2, &supE5_S1_S1_S1_S0_t1};
Transition supE5_S1_S1_S1_S0_t1 = {&b0, &supE5_S1_S0_S1_S0, &supE5_S1_S1_S1_S0_t2};
Transition supE5_S1_S1_S1_S0_t2 = {&b2, &supE5_S1_S1_S0_S0, NULL};

Transition supE5_S1_S1_S1_S1_t0;
Transition supE5_S1_S1_S1_S1_t1;
Transition supE5_S1_S1_S1_S1_t2;
Transition supE5_S1_S1_S1_S1_t0 = {&b1, &supE5_S0_S1_S1_S3, &supE5_S1_S1_S1_S1_t1};
Transition supE5_S1_S1_S1_S1_t1 = {&b0, &supE5_S1_S0_S1_S1, &supE5_S1_S1_S1_S1_t2};
Transition supE5_S1_S1_S1_S1_t2 = {&b2, &supE5_S1_S1_S0_S1, NULL};


// states init
State supE5_S0_S0_S0_S0 = {true, SUP_DEBUG_STR("S0_S0_S0_S0"), &supE5_S0_S0_S0_S0_t0};
State supE5_S0_S0_S0_S1 = {false, SUP_DEBUG_STR("S0_S0_S0_S1"), &supE5_S0_S0_S0_S1_t0};
State supE5_S0_S0_S0_S2 = {false, SUP_DEBUG_STR("S0_S0_S0_S2"), &supE5_S0_S0_S0_S2_t0};
State supE5_S0_S0_S0_S3 = {false, SUP_DEBUG_STR("S0_S0_S0_S3"), &supE5_S0_S0_S0_S3_t0};
State supE5_S0_S0_S1_S0 = {false, SUP_DEBUG_STR("S0_S0_S1_S0"), &supE5_S0_S0_S1_S0_t0};
State supE5_S0_S0_S1_S1 = {false, SUP_DEBUG_STR("S0_S0_S1_S1"), &supE5_S0_S0_S1_S1_t0};
State supE5_S0_S0_S1_S2 = {false, SUP_DEBUG_STR("S0_S0_S1_S2"), &supE5_S0_S0_S1_S2_t0};
State supE5_S0_S0_S1_S3 = {false, SUP_DEBUG_STR("S0_S0_S1_S3"), &supE5_S0_S0_S1_S3_t0};
State supE5_S0_S1_S0_S0 = {false, SUP_DEBUG_STR("S0_S1_S0_S0"), &supE5_S0_S1_S0_S0_t0};
State supE5_S0_S1_S0_S1 = {false, SUP_DEBUG_STR("S0_S1_S0_S1"), &supE5_S0_S1_S0_S1_t0};
State supE5_S0_S1_S0_S2 = {false, SUP_DEBUG_STR("S0_S1_S0_S2"), &supE5_S0_S1_S0_S2_t0};
State supE5_S0_S1_S0_S3 = {false, SUP_DEBUG_STR("S0_S1_S0_S3"), &supE5_S0_S1_S0_S3_t0};
State supE5_S0_S1_S1_S0 = {false, SUP_DEBUG_STR("S0_S1_S1_S0"), &supE5_S0_S1_S1_S0_t0};
State supE5_S0_S1_S1_S1 = {false, SUP_DEBUG_STR("S0_S1_S1_S1"), &supE5_S0_S1_S1_S1_t0};
State supE5_S0_S1_S1_S2 = {false, SUP_DEBUG_STR("S0_S1_S1_S2"), &supE5_S0_S1_S1_S2_t0};
State supE5_S0_S1_S1_S3 = {false, SUP_DEBUG_STR("S0_S1_S1_S3"), &supE5_S0_S1_S1_S3_t0};
State supE5_S1_S0_S0_S0 = {false, SUP_DEBUG_STR("S1_S0_S0_S0"), &supE5_S1_S0_S0_S0_t0};
State supE5_S1_S0_S0_S1 = {false, SUP_DEBUG_STR("S1_S0_S0_S1"), &supE5_S1_S0_S0_S1_t0};
State supE5_S1_S0_S1_S0 = {false, SUP_DEBUG_STR("S1_S0_S1_S0"), &supE5_S1_S0_S1_S0_t0};
State supE5_S1_S0_S1_S1 = {false, SUP_DEBUG_STR("S1_S0_S1_S1"), &supE5_S1_S0_S1_S1_t0};
State supE5_S1_S1_S0_S0 = {false, SUP_DEBUG_STR("S1_S1_S0_S0"), &supE5_S1_S1_S0_S0_t0};
State supE5_S1_S1_S0_S1 = {false, SUP_DEBUG_STR("S1_S1_S0_S1"), &supE5_S1_S1_S0_S1_t0};
State supE5_S1_S1_S1_S0 = {false, SUP_DEBUG_STR("S1_S1_S1_S0"), &supE5_S1_S1_S1_S0_t0};
State supE5_S1_S1_S1_S1 = {false, SUP_DEBUG_STR("S1_S1_S1_S1"), &supE5_S1_S1_S1_S1_t0};

// Supervisor create
Supervisor supE5 = {&supE5_S0_S0_S0_S0, &supE5_S0_S0_S0_S0, NULL,  &supE5_a0_evt0, "supE5"};
