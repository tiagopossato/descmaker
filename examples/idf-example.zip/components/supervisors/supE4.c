#include <stdbool.h>
#include <stdlib.h>

#include "events.h"
#include "supE4.h"

// Supervisor specific instances
// alphabet create
Alphabet supE4_a4_evt0;
Alphabet supE4_a0_evt1;
Alphabet supE4_b4_evt2;
Alphabet supE4_b0_evt3;

// Alphabet init
Alphabet supE4_a4_evt0 = {&a4, &supE4_a0_evt1};
Alphabet supE4_a0_evt1 = {&a0, &supE4_b4_evt2};
Alphabet supE4_b4_evt2 = {&b4, &supE4_b0_evt3};
Alphabet supE4_b0_evt3 = {&b0, NULL};

// states create
State supE4_S0_S0_S0;
State supE4_S0_S1_S1;
State supE4_S1_S0_S1;

// transitions create and init
Transition supE4_S0_S0_S0_t0;
Transition supE4_S0_S0_S0_t1;
Transition supE4_S0_S0_S0_t0 = {&a4, &supE4_S0_S1_S1, &supE4_S0_S0_S0_t1};
Transition supE4_S0_S0_S0_t1 = {&a0, &supE4_S1_S0_S1, NULL};

Transition supE4_S0_S1_S1_t0;
Transition supE4_S0_S1_S1_t0 = {&b4, &supE4_S0_S0_S0, NULL};

Transition supE4_S1_S0_S1_t0;
Transition supE4_S1_S0_S1_t0 = {&b0, &supE4_S0_S0_S0, NULL};


// states init
State supE4_S0_S0_S0 = {true, SUP_DEBUG_STR("S0_S0_S0"), &supE4_S0_S0_S0_t0};
State supE4_S0_S1_S1 = {false, SUP_DEBUG_STR("S0_S1_S1"), &supE4_S0_S1_S1_t0};
State supE4_S1_S0_S1 = {false, SUP_DEBUG_STR("S1_S0_S1"), &supE4_S1_S0_S1_t0};

// Supervisor create
Supervisor supE4 = {&supE4_S0_S0_S0, &supE4_S0_S0_S0, NULL,  &supE4_a4_evt0, "supE4"};
