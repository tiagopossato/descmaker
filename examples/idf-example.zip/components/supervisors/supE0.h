#ifndef __SUPE0_H__
#define __SUPE0_H__

#include <stdbool.h>
#include <stdlib.h>

#include "supervisor.h"
// Supervisor create
extern Supervisor supE0;

#endif // __SUPE0_H__