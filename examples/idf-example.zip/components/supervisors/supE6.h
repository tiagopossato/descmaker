#ifndef __SUPE6_H__
#define __SUPE6_H__

#include <stdbool.h>
#include <stdlib.h>

#include "supervisor.h"
// Supervisor create
extern Supervisor supE6;

#endif // __SUPE6_H__